// ============================================================
// RAD Digital — configuração da nuvem (Firebase)
// 1) No console do Firebase: ⚙️ Configurações do projeto → Seus apps → </> Web
// 2) Copie os valores do bloco "firebaseConfig" e cole entre as aspas abaixo.
// 3) "empresa" separa os dados de cada empresa (use só letras minúsculas, sem espaço).
// Enquanto projectId estiver vazio, o sistema funciona só no aparelho (sem nuvem).
// ============================================================
window.RAD_CLOUD = {
  empresa: "gavea",
  config: {
    apiKey: "",
    authDomain: "",
    projectId: "",
    storageBucket: "",
    messagingSenderId: "",
    appId: ""
  }
};
