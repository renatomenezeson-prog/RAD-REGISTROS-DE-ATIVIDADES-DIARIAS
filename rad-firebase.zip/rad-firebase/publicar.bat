@echo off
chcp 65001 >nul
echo ================================================
echo   Publicar RAD Digital no Firebase
echo ================================================
echo.
where node >nul 2>nul || (echo Instale o Node.js antes: https://nodejs.org  ^(versao LTS^) & pause & exit /b)
set /p PROJ=Digite o ID do projeto Firebase (ex.: rad-digital-gavea): 
echo.
echo 1/2 - Entrando na sua conta Google (vai abrir o navegador)...
call npx -y firebase-tools@latest login
echo.
echo 2/2 - Publicando o site e as regras de seguranca...
call npx -y firebase-tools@latest deploy --only hosting,firestore:rules --project %PROJ%
echo.
echo Pronto! O endereco do sistema e: https://%PROJ%.web.app
pause
